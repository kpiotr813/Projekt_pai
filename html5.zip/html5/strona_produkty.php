<?php
// Tablica z kategoriami i odpowiadającymi im plikami
$menu = array(
    'kategoria_1.php' => 'Kategoria 1',
    'kategoria_2.php' => 'Kategoria 2',
    'kategoria_3.php' => 'Kategoria 3',
    'kategoria_4.php' => 'Kategoria 4'
);
foreach ($menu as $key => $value):
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <title>Strona z produktami</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box; /* Wszystkie elementy uwzględniają padding i border w wysokości */
}
    .navbar {
    font-family: Montserrat, sans-serif;
    margin-bottom: 0;
    background-color: darkgray;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    margin-top: 0px;
    }

    .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
    }

    .navbar-nav li a:hover, .navbar-nav li.active a {
    color: darkgrey !important;
    background-color: #fff !important;
    }
    .jumbotron {
    display: flex;               
    justify-content: center;     
    align-items: center; 
    background-color: grey; 
    height: 20px;
    color: white; 
    box-sizing: border-box;
    margin-top: 0px; 
    margin-bottom:0px;
    box-sizing: border-box;
    }
    .jumbotron p {
        font-size: 30px; 
    }
    #zawartosc{
        height:1000px;
    }
    
  </style>
</head>
<body>

    <div class="jumbotron">
        <p>Strona główna</p>
    </div>

    <nav class="navbar">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="#myPage">Logo</a>
          </div>
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#about">Strona główna</a></li>
              <li><a href="#services">Kategorie</a></li>
              <li><a href="#portfolio">Kontakt</a></li>
            </ul>
          </div>
        </div>
      </nav> 

      <div id="zawartosc" class="container-fluid">
        
        <h2>About Company Page</h2>
        <h4>Lorem ipsum..</h4>      
        <p>Lorem ipsum..</p>
        
      </div>

      <div id="contact" class="container-fluid bg-grey">
        <h2 class="text-center">Kontakt</h2>
        <div class="row">
          <div class="col-sm-5">
            <p>Skontaktuj się z nami, a oddzwonimy w ciągu 24 godzin.</p>
            <p><span class="glyphicon glyphicon-map-marker"></span> Nowa Wieś</p>
            <p><span class="glyphicon glyphicon-phone"></span> +123456789</p>
            <p><span class="glyphicon glyphicon-envelope"></span> nowy_mail@gmail.com</p>
          </div>
          <div class="col-sm-7">
            <div class="row">
              <div class="col-sm-6 form-group">
                <input class="form-control" id="name" name="name" placeholder="Nazwisko" type="text" required>
              </div>
              <div class="col-sm-6 form-group">
                <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
              </div>
            </div>
            <textarea class="form-control" id="comments" name="comments" placeholder="Komentarz" rows="5"></textarea><br>
            <div class="row">
              <div class="col-sm-12 form-group">
                <button class="btn btn-default pull-right" type="submit">Wyślij</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    
      <footer class="container-fluid text-center">
        <a href="#myPage" title="To Top">
          <span class="glyphicon glyphicon-chevron-up"></span>
        </a>
        <p>Bootstrap Theme Made By <a href="https://www.w3schools.com" title="Visit w3schools">www.w3schools.com</a></p>
      </footer>



</body>
</html>