<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pai_koska";
$conn = mysqli_connect($servername, $username, $password, $dbname);
$sql="SELECT id,nazwa,img,model,silnik,rok,przebieg,spalanie,naped,skrzynia,miejscowosc,wojewodztwo,imie,nazwisko,telefon,mail,cena
      FROM produkty
      WHERE kategoria_id=1";
$wynik=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <title>Samochody</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

  <style>
    .jumbotron {
        height: 100 px;
        background-color: white;
        display: flex; /* Ustawienie kontenera na Flexbox */
      justify-content: center; /* Centrowanie poziome */
      align-items: center;
    }
    .jumbotron p {
        font-size:60px;
        font-family: Montserrat, sans-serif;
    }
    .container-fluid{
        height: 200px;
        
        margin-bottom: 20px;
        display: flex;
    }
    #zdjecie {
        height: 180px;
        width: 300px;
        margin-left: 10px; 
        margin-top: 10px;  
        margin-bottom: 10px;
        background-color: white;
        overflow: hidden;
    }
    #zdjecie img {
      width: 100%;  /* Ustawienie szerokości zdjęcia na 100% szerokości kontenera */
      height: auto; /* Wysokość dostosowuje się do proporcji */
      object-fit: contain; /* Upewnia się, że zdjęcie zmienia swoje wymiary, ale nie wychodzi poza kontener */
    }
    #srodek {
        height:180px;
        width:600px;
        margin-left: 10px; 
        margin-top: 10px;  
        margin-bottom: 10px;
        background-color: grey;
        display: flex; /* Ustawienie kontenera na Flexbox */
        justify-content: center; /* Centrowanie poziome */
      align-items: center;
    }
    #prawo{
        height:180px;
        width:300px;
        margin-left: 10px; 
        margin-top: 10px;  
        margin-bottom: 10px;
        background-color: grey;
        display: flex; /* Ustawienie kontenera na Flexbox */
      justify-content: center; /* Centrowanie poziome */
      align-items: center;
    }
    #cena{
        height:85%;
        width:85%;
        background-color:white;
        display: flex; /* Ustawienie kontenera na Flexbox */
      justify-content: center; /* Centrowanie poziome */
      align-items: center;
    }
    #cena p{
        font-size: 50px;
        font-family: Montserrat, sans-serif;
    }
    #dane_tech{
        height:160px;
        width:180px;
        background-color: white;
        padding: 0; /* Usuwamy domyślne wcięcia wewnętrzne kontenera */
    margin: 0;
    padding: 5px;
    overflow: hidden;
    overflow-y: auto;
    font-family: Montserrat, sans-serif;
    }
    #dane_tech p {
        line-height: 1;
        font-family: Montserrat, sans-serif;
    }
    #lokalizacja p {
        line-height: 1.2;
        font-family: Montserrat, sans-serif;
    }
    #lokalizacja{
        height:160px;
        width:180px;
        background-color: white;
        font-family: Montserrat, sans-serif;
    }
    #kontakt_do{
        height:160px;
        width:180px;
        background-color: white;
        font-family: Montserrat, sans-serif;
    }
    h1 {
        font-size: 16px;
        font-weight: bold;
        margin-top: 0px;
    }
    
   hr {
    border-color: grey;
    width: 90%;
    margin-left: 5%;
    margin-right: 5%;
   } 
   
   
   

  </style>
</head>
<body>
<div class="jumbotron">
    <p>Samochody osobowe na sprzedaż</p>
</div>




<?php

if (mysqli_num_rows($wynik)>0){

    while ($produkt=mysqli_fetch_array($wynik)){
    echo "
    <div id='volvo' class='container-fluid'>
    <div id='zdjecie' class='container'>
    <a href='$produkt[img]' data-lightbox='gallery$produkt[id]' data-title='$produkt[nazwa]'>
        <img src='$produkt[img]' >
    </a>

    </div>

    <div id='srodek' class='container'>
        <div id='dane_tech' class='container'>
            <h1>Dane techniczne:</h1>
            <p>Model: $produkt[model]</p>
            <p>Silnik: $produkt[silnik]</p>
            <p>Rok produkcji: $produkt[rok]</p>
            <p>Przebieg: $produkt[przebieg]</p>
            <p>Spalanie: $produkt[spalanie]</p>
            <p>Napęd: $produkt[naped]</p>
            <p>Skrzynia biegów: $produkt[skrzynia]</p>
        </div>
        <div id='lokalizacja' class='container'>
            <h1>Lokalizacja:</h1>
            <p>$produkt[miejscowosc]</p>
            <p>Woj. $produkt[wojewodztwo]</p>
        </div>
        <div id='kontakt_do' class='container'>
            <h1>Kontakt:</h1>
            <p>$produkt[imie] $produkt[nazwisko]</p>
            <p>Tel. +48 $produkt[telefon]</p>
            <p>$produkt[mail]</p>
        </div>
    </div>

    <div id='prawo' class='container'>
        <div id='cena' class='container'>
            <p>$produkt[cena] zł</p>
        </div>
    </div>
</div>
<hr>

    ";}

}






mysqli_close($conn);
?>
</body>
</html>